def say_hello():
    print('Welcome to the Brain Games!')
    name = input('May I have your name?')
    print(f"Hello,{name}!")
    print('Answer "yes" if the number is even, otherwise answer "no".')
    return name

