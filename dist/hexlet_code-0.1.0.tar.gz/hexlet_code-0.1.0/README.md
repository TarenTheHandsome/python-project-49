### Hexlet tests and linter status:
[![Actions Status](https://github.com/TarenTheHandsome/python-project-49/actions/workflows/hexlet-check.yml/badge.svg)](https://github.com/TarenTheHandsome/python-project-49/actions)
<a href="https://codeclimate.com/github/TarenTheHandsome/python-project-49/maintainability"><img src="https://api.codeclimate.com/v1/badges/655ef140eaf0e79645c3/maintainability" /></a>
https://asciinema.org/a/6JXAiQysBHUpmi6Cx9DVoWpCX