### BRAIN GAMES
### Hexlet tests and linter status:
[![Actions Status](https://github.com/TarenTheHandsome/python-project-49/actions/workflows/hexlet-check.yml/badge.svg)](https://github.com/TarenTheHandsome/python-project-49/actions)
<a href="https://codeclimate.com/github/TarenTheHandsome/python-project-49/maintainability"><img src="https://api.codeclimate.com/v1/badges/655ef140eaf0e79645c3/maintainability" /></a>
### Description:
Package with five games to exercise your brain.
### Examples of working with the package:
Brain-even: https://asciinema.org/a/XFAacLWrcHKLTOlBCkwTSe5C9

Brain-calc: https://asciinema.org/a/5NveZT6adDaU4iCREWWWHtTx2

Brain-gcd: https://asciinema.org/a/hyXt3IMVe1i9bb1ZG2wul2Ht4

Brain-progression: https://asciinema.org/a/J1NmGG3VcsvCc8YTt2m7A1IAc

Brain-prime: https://asciinema.org/a/tVhPRq0bAHtNqACK7Tab7XhGz