### BRAIN GAMES
### Hexlet tests and linter status:
[![Actions Status](https://github.com/TarenTheHandsome/python-project-49/actions/workflows/hexlet-check.yml/badge.svg)](https://github.com/TarenTheHandsome/python-project-49/actions)
<a href="https://codeclimate.com/github/TarenTheHandsome/python-project-49/maintainability"><img src="https://api.codeclimate.com/v1/badges/655ef140eaf0e79645c3/maintainability" /></a>
### Description:
Package with five games to exercise your brain.
### Examples of working with the package:
 Brain-even: https://asciinema.org/a/XFAacLWrcHKLTOlBCkwTSe5C9

 Brain-calc: 
https://asciinema.org/a/5zREcEsxc5PaBTMEQxJ34kd59
https://asciinema.org/a/1jbypLqCecACQV5j4RPHMY5C4
https://asciinema.org/a/tUoBwEBQKFR779g70rD4Rc6d8