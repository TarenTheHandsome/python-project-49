#!/usr/bin/env python3
def print_welcome():
    print('Welcome to the Brain Games!')

def main():
    print_welcome()


if __name__ == '__main__':
    main()
